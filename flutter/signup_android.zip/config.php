<?php

$db_host = "sql213.infinityfree.com" ;
$db_username = "if0_34664423";
$db_password = "Ac3tDQRbaAQlH2N ";
$db_name = "if0_34664423_project";

$db_con = mysqli_connect($db_host,$db_username,$db_password,$db_name) or die("Database Connection Error");

$category_path = 'http://hd-infotech.com/Android_Session/flutter/images/category/';

$product_path = 'http://hd-infotech.com/Android_Session/flutter/images/product/';

?>